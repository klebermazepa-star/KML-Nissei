/********************************************************************************
** Programa: INT020-5RP - Geracao notas fiscais a partir de Cupom Fiscal PRS
**
** Versao : 12 - 20/03/2016 - Alessandro V Baccin
**
********************************************************************************/
/* include de controle de versao */
{include/i-prgvrs.i INT020-5RP 2.12.01.AVB}
{cdp/cdcfgdis.i}

/* defini�ao das temp-tables para recebimento de parametros */
def temp-table tt-param no-undo
    field destino          as integer
    field arquivo          as char format "x(35)"
    field usuario          as char format "x(12)"
    field data-exec        as date
    field hora-exec        as integer
    field classifica       as integer
    field desc-classifica  as char format "x(40)".

def temp-table tt-raw-digita
        field raw-digita	as raw.

def temp-table tt-cst-nota-fiscal like cst-nota-fiscal.
def temp-table tt-int-ds-nota-loja-cartao like int-ds-nota-loja-cartao
    field cod-esp       like fat-duplic.cod-esp
    field cod-vencto    like fat-duplic.cod-vencto
    field cod-cond-pag  like nota-fiscal.cod-cond-pag
    field cod-portador  like nota-fiscal.cod-portador
    field modalidade    like nota-fiscal.modalidade.

def temp-table tt-int-ds-nota-loja-5 like int-ds-nota-loja
    field rowid-nota-loja as rowid
    INDEX r-rowid IS UNIQUE rowid-nota-loja
    index data
          emissao.

{cdp/cd4305.i1}  /* Definicao da temp-table tt-docto e tt-it-doc            */
{cdp/cd4314.i2}  /* Definicao da temp-table tt-nota-trans                   */
{cdp/cd4401.i3}  /* Definicao da temp-table tt-saldo-estoq                  */
{cdp/cd4313.i1}  /* Def da temp-table tt-cond-pag e tt-fat-duplic           */
{cdp/cd4313.i4}  /* Def da temp-table tt-rateio-it-duplic                   */
{ftp/ft2070.i1}  /* Definicao da temp-table tt-fat-repre                    */
{ftp/ft2073.i1}  /* Definicao das temp-tables tt-nota-embal e tt-item-embal */
{ftp/ft2010.i1}  /* Definicao da temp-table tt-notas-geradas                */
{ftp/ft2015.i}   /* Temp-table tt-docto-bn e tt-it-docto-bn                 */
{cdp/cd4305.i2}  /* Temp-table tt-it-nota-doc                               */
{ftp/ft2015.i2}  /* Temp-table tt-desp-nota-fisc                            */

/* temp-tables das API's e BO's */
{method/dbotterr.i}

/* recebimento de parametros */
def input parameter raw-param as raw no-undo.
def input parameter table for tt-raw-digita.  

create tt-param.                    
raw-transfer raw-param to tt-param NO-ERROR. 
IF tt-param.arquivo = "" THEN 
    ASSIGN tt-param.arquivo = "INT020-5.txt"
           tt-param.destino = 3
           tt-param.data-exec = TODAY
           tt-param.hora-exec = TIME.

/* include padrao para vari�veis de relat�rio  */
{include/i-rpvar.i}

/* ++++++++++++++++++ (Definicao Stream) ++++++++++++++++++ */

/* ++++++++++++++++++ (Definicao Buffer) ++++++++++++++++++ */
define buffer bemitente for emitente.

{intprg/int020rp.i2} /* Defini��o de vari�veis */

{utp/ut-glob.i}

/* defini�ao de frames do relat�rio */
form i-nr-registro    column-label "Sequencia"
     tb-erro[1]       column-label "Mensagem"
     c-informacao     column-label "Conteudo"
     with no-box no-attr-space width 300
     down stream-io frame f-erro.

/* include com a defini�ao da frame de cabe�alho e rodap� */
/*{include/i-rpcab.i &stream="str-rp"}*/
{include/i-rpcab.i}
/* bloco principal do programa */

function OnlyNumbers returns char
    (p-char as char):

    def var i-ind as integer no-undo.
    def var c-aux as char no-undo.
    do i-ind = 1 to length (p-char):
        if lookup (substring(p-char,i-ind,1),"1,2,3,4,5,6,7,8,9,0") > 0 then
            assign c-aux = c-aux + substring(p-char,i-ind,1).
    end.
    return c-aux.
end.

find first tt-param no-lock no-error.
assign c-programa       = "INT020-5RP"
       c-versao         = "2.12"
       c-revisao        = ".01.AVB"
       c-empresa        = "* Nao Definido *"
       c-sistema        = "Faturamento"
       c-titulo-relat   = "Importa��o de Notas Fiscais - Cupons - PRS".

/* ----- inicio do programa ----- */
for first param-global no-lock: end.
for mgadm.empresa fields (razao-social) where
    empresa.ep-codigo = param-global.empresa-prin no-lock: end.
assign c-empresa = mgadm.empresa.razao-social
       i-cupom   = 0.

do:
   run utp/ut-acomp.p persistent set h-acomp.
   run pi-inicializar in h-acomp (input "Processando").

   IF tt-param.arquivo <> "" THEN DO:
       /*{include/i-rpout.i &stream = "stream str-rp"}*/
       {include/i-rpout.i}
                             
       view /*stream str-rp*/ frame f-cabec.
       view /*stream str-rp*/ frame f-rodape.
   END.
   FOR FIRST int-ds-ger-cupom NO-LOCK: END.
   IF NOT AVAIL int-ds-ger-cupom THEN DO:
       assign i-erro = 45
              c-informacao = "".
       run gera-log. 
       /* fechamento do output do relatorio  */
       IF tt-param.arquivo <> "" THEN DO:
           /*{include/i-rpclo.i &stream="stream str-rp"}*/
           {include/i-rpclo.i}
       END.
       /* elimina BO's */
       return "OK".
   END.
   run pi-importa.

   pause 3 no-message.
end.
/* ----- fim do programa -------- */
run pi-elimina-tabelas.
run pi-finalizar in h-acomp.

/* fechamento do output do relatorio  */
IF tt-param.arquivo <> "" THEN DO:
    /*{include/i-rpclo.i &stream="stream str-rp"}*/
    {include/i-rpclo.i}
END.
/* elimina BO's */
return "OK".

/* procedures */

procedure pi-elimina-tabelas.
   run pi-acompanhar in h-acomp (input "Eliminando Tabelas Temporarias").
   /* limpa temp-tables */
   empty temp-table tt-docto.
   empty temp-table tt-it-docto.
   empty temp-table tt-it-imposto.
   empty temp-table tt-saldo-estoq.
   empty temp-table tt-nota-trans.
   empty temp-table tt-fat-duplic.
   empty temp-table tt-fat-repre.
   empty temp-table tt-nota-embal.
   empty temp-table tt-item-embal.
   empty temp-table tt-cst-nota-fiscal. 
   empty temp-table tt-fat-duplic. 
   empty temp-table tt-int-ds-nota-loja-cartao. 
   empty temp-table tt-notas-geradas .
   empty temp-table RowErrors.   
end.        

procedure pi-importa:
    
    assign i-nr-registro  = 0
           i-nr-sequencia = 0.

    EMPTY TEMP-TABLE tt-int-ds-nota-loja-5.

    FOR EACH estabelec USE-INDEX codigo WHERE 
             estabelec.cod-estabel >= int-ds-ger-cupom.cod-estab-ini-5 AND
             estabelec.cod-estabel <= int-ds-ger-cupom.cod-estab-fim-5 NO-LOCK:

        for each int-ds-nota-loja no-lock USE-INDEX sit_cnpj_emiss where 
                 int-ds-nota-loja.situacao    = 1 AND
                 int-ds-nota-loja.cnpj_filial = estabelec.cgc
                 query-tuning(no-lookahead):
            
            run pi-acompanhar in h-acomp (input "Carregando informa��es: " + estabelec.cod-estabel + " - " + string(int-ds-nota-loja.emissao,"99/99/9999")).

            FOR FIRST tt-int-ds-nota-loja-5 WHERE 
                tt-int-ds-nota-loja-5.rowid-nota-loja = ROWID(int-ds-nota-loja): END.
            IF NOT AVAIL tt-int-ds-nota-loja-5 THEN DO:
                CREATE tt-int-ds-nota-loja-5.
                BUFFER-COPY int-ds-nota-loja TO tt-int-ds-nota-loja-5.
                ASSIGN tt-int-ds-nota-loja-5.rowid-nota-loja = ROWID(int-ds-nota-loja).
            END.

        end.
    END.

    FOR EACH tt-int-ds-nota-loja-5 USE-INDEX data:
        FOR FIRST int-ds-nota-loja WHERE ROWID(int-ds-nota-loja) = tt-int-ds-nota-loja-5.rowid-nota-loja NO-LOCK:
        END.
        IF AVAIL int-ds-nota-loja THEN DO:
           
           run pi-acompanhar in h-acomp (input "Processando dia: " + string(int-ds-nota-loja.emissao,"99/99/9999")).
           {intprg/int020rp.i}

        END.
    END.

    run importa-nota.
    run pi-elimina-tabelas.
end.

{intprg/int020rp.i1}

